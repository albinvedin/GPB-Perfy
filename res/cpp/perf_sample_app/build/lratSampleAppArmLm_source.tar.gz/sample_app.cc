#include <iostream>

int main (int argc, char **argv)
{
  std::cout << "hej" << std::endl;
  return 0;
}
